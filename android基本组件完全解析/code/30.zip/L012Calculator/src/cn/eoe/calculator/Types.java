package cn.eoe.calculator;

public class Types {

	public static final int ADD = 1;
	public static final int SUB = 2;
	public static final int X = 3;
	public static final int DIV = 4;
	public static final int NUM = 5;
	
}
