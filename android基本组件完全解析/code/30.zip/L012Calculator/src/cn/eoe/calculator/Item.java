package cn.eoe.calculator;

public class Item {

	public Item(double value,int type) {
		this.value= value;
		this.type=type;
	}
	
	public double value = 0;
	
	public int type  = 0;
}
