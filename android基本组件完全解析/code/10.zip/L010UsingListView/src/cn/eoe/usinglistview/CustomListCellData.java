package cn.eoe.usinglistview;

public class CustomListCellData {

	public CustomListCellData(String name,String dec,int iconId) {
		this.name=name;
		this.dec=dec;
		this.iconId=iconId;
	}
	
	
	public String name="";
	public String dec="";
	public int iconId=0;
	
}
