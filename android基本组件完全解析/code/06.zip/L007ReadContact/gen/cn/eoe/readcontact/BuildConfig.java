/** Automatically generated file. DO NOT MODIFY */
package cn.eoe.readcontact;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}