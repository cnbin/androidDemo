package cn.eoe.uicontrols;

import android.app.Activity;
import android.os.Bundle;

public class AtyUsingScrollView extends Activity {

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.aty_using_scrollview);
	}
}
