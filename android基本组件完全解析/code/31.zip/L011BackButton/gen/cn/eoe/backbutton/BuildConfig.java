/** Automatically generated file. DO NOT MODIFY */
package cn.eoe.backbutton;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}